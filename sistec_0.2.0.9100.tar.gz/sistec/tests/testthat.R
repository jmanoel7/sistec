library(testthat)
library(sistec)

test_check("sistec")
